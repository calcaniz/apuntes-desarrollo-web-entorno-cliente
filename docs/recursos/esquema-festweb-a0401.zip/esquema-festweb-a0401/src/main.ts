import "./style.css";

console.log("FestWeb se ha cargado correctamente");

// La actividad A04.01 se desarrollará a partir de este punto.